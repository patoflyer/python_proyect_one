precio = [50, 75, 46, 22, 80, 65, 8]

men = min(precio)
may = max(precio)

print("El precio menor es:", men)
print("El precio mayor es:", may)
